import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

import { RootStackParamList } from '../../navigator';
import { SERVER_BASE_URL } from '@env';

// ✅ 프로필(이름) 불러오기: ResultScreen에 personName 전달
import { loadUserProfile } from '../storage/userProfile';

import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';

type InputRouteProp = RouteProp<RootStackParamList, 'Input'>;
type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

const InputScreen = () => {
  const route = useRoute<InputRouteProp>();
  const navigation = useNavigation<NavigationProp>();

  // ✅ route.params가 없을 수도 있으니 안전하게 처리(크래시 방지)
  const dreamText = route.params?.dreamText ?? '';

  const [personName, setPersonName] = useState<string | undefined>(undefined);

  useEffect(() => {
    // ✅ 파라미터 없이 들어오면 Home으로 되돌리기
    if (!dreamText.trim()) {
      Alert.alert('알림', '꿈 내용이 없어 홈으로 이동합니다.');
      navigation.replace('Home');
      return;
    }

    const run = async () => {
      try {
        // 1) 프로필 로드(실패해도 진행)
        try {
          const profile = await loadUserProfile();
          const name = profile.name?.trim();
          setPersonName(name ? name : undefined);
        } catch (e) {
          console.warn('⚠️ 프로필 로드 실패(무시 가능):', e);
          setPersonName(undefined);
        }

        // 2) split 요청
        console.log('📡 SERVER_BASE_URL =', SERVER_BASE_URL);
        console.log('📨 요청 URL =', `${SERVER_BASE_URL}/split`);

        const response = await fetch(`${SERVER_BASE_URL}/split`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: dreamText.trim() }),
        });

        if (!response.ok) {
          const errText = await response.text();
          console.error('❌ /split 응답 에러:', errText);
          Alert.alert('오류', '서버 응답이 올바르지 않습니다.');
          navigation.replace('Home');
          return;
        }

        const data = await response.json();

        if (!Array.isArray(data.sentences)) {
          Alert.alert('오류', '문장 분리 결과가 없습니다.');
          navigation.replace('Home');
          return;
        }

        // 3) Result로 이동 (Input은 스택에 남지 않게 replace)
        navigation.replace('Result', {
          sentenceList: data.sentences,
          dreamText: dreamText.trim(),
          usedGPTInSplit: !!data.usedGPT,
          personName,
        });
      } catch (error) {
        console.error('❌ 서버 요청 에러:', error);
        Alert.alert('오류', '서버 연결에 실패했습니다.');
        navigation.replace('Home');
      }
    };

    run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dreamText]);

  return (
    <View style={styles.container}>
      <ActivityIndicator size="small" color={Colors.accentPrimary} />
      <Text style={styles.status}>문장을 정리하고 있어요…</Text>
      <Text style={styles.muted}>잠시만 기다려주세요</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.backgroundPrimary,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    gap: 10,
  },
  status: {
    ...Typography.body,
  },
  muted: {
    ...Typography.muted,
  },
});

export default InputScreen;
