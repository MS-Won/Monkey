import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';
import { loadUserProfile } from '../storage/userProfile';

export default function HomeScreen() {
  const [name, setName] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const profile = await loadUserProfile();
        setName(profile?.name ?? null);
      } catch {
        setName(null);
      }
    })();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.greeting}>
        {name ? `${name}님, 오늘 꿈을 기록해볼까요?` : '오늘 꿈을 기록해볼까요?'}
      </Text>

      <Text style={Typography.muted}>
        아래 입력 버튼을 눌러 꿈을 기록하세요.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.backgroundPrimary,
    padding: 20,
  },
  greeting: {
    ...Typography.h2,
    fontSize: 18,
    marginBottom: 8,
  },
});
